<template>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h4>Add Students</h4>
      </div>
      <div class="card-body">
        <ul class="alert alert-warning" v-if="errorList.length > 0">
          <li class="mb-0 ms-3" v-for="(error, index) in errorList" :key="index">
            {{ error }}
          </li>
        </ul>
        <div class="mb-3">
          <label for="">Name</label>
          <input type="text" v-model="model.student.name" class="form-control" />
        </div>
        <div class="mb-3">
          <label for="">Member Id</label>
          <input type="text" v-model="model.student.member_id" class="form-control" />
        </div>
        <div class="mb-3">
          <button @click="saveStudent" type="button" class="btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'studentCreate',
  data() {
    return {
      errorList: [],
      model: {
        student: {
          name: '',
          member_id: ''
        }
      }
    }
  },
  methods: {
    saveStudent() {
      axios
        .post('http://localhost/authblog_api/public/api/validate', this.model.student, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          alert(res.data.result)
          this.model.student = {
            name: '',
            member_id: ''
          }
          this.errorList = []
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status == 401) {
              this.errorList = Object.values(error.response.data).flat()
            } else if (error.request) {
              console.log(error.request)
            } else {
              console.log('Error', error.message)
            }
          } else {
            console.log('Error', error.message)
          }
        })
    }
  }
}
</script>
