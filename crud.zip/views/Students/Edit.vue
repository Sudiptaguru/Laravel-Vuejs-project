<template>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h4>Edit Student</h4>
      </div>
      <div class="card-body">
        <ul class="alert alert-warning" v-if="showErrors && globalErrors.length > 0">
          <li class="mb-0 ms-3" v-for="(error, index) in globalErrors" :key="index">
            {{ error }}
          </li>
        </ul>
        <div class="mb-3">
          <label for="name">Name</label>
          <input 
            type="text" 
            v-model="student.name" 
            class="form-control" 
            id="name" 
            :class="{'is-invalid': errorList.name.length > 0}" 
          />
          <div class="invalid-feedback" v-for="(error, index) in errorList.name" :key="index">
            {{ error }}
          </div>
        </div>
        <div class="mb-3">
          <label for="memberId">Member Id</label>
          <input 
            type="text" 
            v-model="student.member_id" 
            class="form-control" 
            id="memberId" 
            :class="{'is-invalid': errorList.member_id.length > 0}" 
          />
          <div class="invalid-feedback" v-for="(error, index) in errorList.member_id" :key="index">
            {{ error }}
          </div>
        </div>
        <div class="mb-3">
          <button @click="saveStudent" type="button" class="btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'StudentEdit',
  data() {
    return {
      globalErrors: [],
      errorList: {
        name: [],
        member_id: []
      },
      student: {
        id: '',
        name: '',
        member_id: ''
      }
    }
  },
  mounted() {
    this.getStudentData(this.$route.params.id)
  },
  methods: {
    getStudentData(studentId) {
      axios
        .get(`http://localhost/authblog_api/public/api/list/${studentId}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          this.student = res.data
        })
        .catch((error) => {
          console.error('Error fetching student data:', error)
        })
    },
    saveStudent() {
      axios
        .put('http://localhost/authblog_api/public/api/update', this.student, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          alert(res.data.result)
          // Update the student data with the response (if the API returns the updated data)
          if (res.data.updatedStudent) {
            this.student = res.data.updatedStudent
          }
          this.errorList = { name: [], member_id: [] } // Clear errors
          this.globalErrors = [] // Clear global errors
        })
        .catch((error) => {
          if (error.response && error.response.status === 401) {
            // Assuming errors are grouped by field names
            this.errorList = {
              name: error.response.data.name || [],
              member_id: error.response.data.member_id || []
            }
            this.globalErrors = [] // Clear global errors
          } else {
            // Handle other types of errors
            this.globalErrors = [error.response.data.message || 'An error occurred.']
            this.errorList = { name: [], member_id: [] }
          }
        })
    }
  }
}
</script>
