<template>
  <div>
    <h2>Data List</h2>
    
    <!-- Search Field -->
    <div class="search-container">
      <input v-model="searchQuery" @keyup.enter="searchImages" placeholder="Search by title..." />
      <button @click="searchImages" class="btn btn-primary">Search</button>
    </div>

    <table class="table">
      <thead>
        <tr>
          <th>Image</th>
          <th>Title</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="image in images.data" :key="image.id">
          <td>
            <img :src="`http://localhost:8000/storage/images/${image.image_path}`" :alt="image.title" width="100" />
          </td>
          <td>{{ image.title }}</td>
          <td>
            <router-link :to="`/edit/${image.id}`" class="btn btn-primary">Edit</router-link>
            <button @click="confirmDelete(image.id)" class="btn btn-danger">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    
    <!-- Pagination Links -->
    <div class="pagination">
      <button 
        v-if="images.prev_page_url" 
        @click="fetchImages(images.prev_page_url)"
        class="btn btn-secondary"
      >
        Previous
      </button>
      <button 
        v-if="images.next_page_url" 
        @click="fetchImages(images.next_page_url)"
        class="btn btn-secondary"
      >
        Next
      </button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      images: {
        data: [], // Data for the current page
        current_page: 1, // Current page number
        prev_page_url: null, // URL for the previous page
        next_page_url: null // URL for the next page
      },
      searchQuery: '', // Search query for the title
      perPage: 10 // Items per page
    };
  },
  created() {
    this.fetchImages();
  },
  methods: {
    fetchImages(pageUrl = null) {
      const url = pageUrl || `http://localhost:8000/api/images?per_page=${this.perPage}&page=${this.images.current_page}`;
      axios.get(url)
        .then(response => {
          this.images = response.data;
        })
        .catch(error => {
          console.error('There was an error fetching the images!', error);
        });
    },
    searchImages() {
      const data = {
        title: this.searchQuery,
        per_page: this.perPage
      };
      axios.post('http://localhost:8000/api/images_search', data)
        .then(response => {
          this.images = response.data;
        })
        .catch(error => {
          console.error('There was an error searching the images!', error);
        });
    },
    confirmDelete(id) {
      const confirmation = confirm('Are you sure you want to delete this image?');
      if (confirmation) {
        this.deleteImage(id);
      }
    },
    deleteImage(id) {
      axios.delete(`http://localhost:8000/api/images/${id}`)
        .then(response => {
          this.fetchImages();
          alert(response.data.message);
        })
        .catch(error => {
          console.error('There was an error deleting the image!', error);
        });
    }
  }
};
</script>

<style scoped>
.table {
  width: 100%;
  border-collapse: collapse;
}
.table th, .table td {
  border: 1px solid #ddd;
  padding: 8px;
}
.table th {
  background-color: #f4f4f4;
}
.table img {
  max-width: 100px;
}
.btn {
  margin-right: 5px;
}
.pagination {
  margin-top: 20px;
  text-align: center;
}
.search-container {
  margin-bottom: 20px;
}
</style>
