<template>
  <div>
    <h2>Add Image</h2>
    <form @submit.prevent="uploadImage">
      <div>
        <label for="title">Title</label>
        <input type="text" v-model="title" id="title" />
        <span v-if="errors.title" class="text-danger">{{ errors.title }}</span>
      </div>
      <div>
        <label for="image">Image</label>
        <input type="file" @change="onFileChange" id="image" />
        <span v-if="errors.image" class="text-danger">{{ errors.image }}</span>
      </div>
      <div v-if="imagePreview">
        <h3>Image Preview:</h3>
        <img :src="imagePreview" alt="Image preview" width="200" />
      </div>
      <button type="submit">Upload</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      title: '',
      image: null,
      imagePreview: null,
      errors: {}
    };
  },
  methods: {
    onFileChange(event) {
      const file = event.target.files[0];
      this.image = file;

      if (file) {
        this.imagePreview = URL.createObjectURL(file);
      } else {
        this.imagePreview = null;
      }
    },
    validate() {
      this.errors = {};
      if (!this.title) {
        this.errors.title = 'Title is required.';
      }
      if (!this.image) {
        this.errors.image = 'Image is required.';
      } else if (!['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/svg+xml'].includes(this.image.type)) {
        this.errors.image = 'Invalid image format. Only jpeg, png, jpg, gif, and svg are allowed.';
      } else if (this.image.size > 2048 * 1024) {
        this.errors.image = 'Image size exceeds 2MB.';
      }
      return Object.keys(this.errors).length === 0;
    },
    uploadImage() {
      if (!this.validate()) return;

      const formData = new FormData();
      formData.append('title', this.title);
      formData.append('image', this.image);

      axios.post('http://localhost/authblog_api/public/api/images', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(response => {
          alert(response.data.message);
          this.$router.push('/datalist');
        })
        .catch(error => {
          console.error('There was an error uploading the image!', error);
        });
    }
  }
};
</script>

<style scoped>
.text-danger {
  color: red;
}
</style>
