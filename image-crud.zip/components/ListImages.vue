<template>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2>Data List</h2>
            <router-link class="btn btn-primary" to="/add">Add Data</router-link>
        </div>
        <div class="card-body">
            <!-- Search Field -->
            <div class="search-container">
                <input v-model="searchQuery" @keyup.enter="searchImagesinput" placeholder="Search by title..." />
                <button @click="searchImagesinput" class="btn btn-primary">Search</button>
            </div>
            <div class="mb-3 row">
                <div class="col-md-12 position-relative">
                    <input type="text" v-model="searchTitle" @input="fetchTitleSuggestions" placeholder="Search by Title" class="form-control" />
                    <!-- Suggestions Dropdown for Title -->
                    <ul v-if="titleSuggestions.length" class="autocomplete-list">
                        <li v-for="(suggestion, index) in titleSuggestions" :key="index" @click="selectTitleSuggestion(suggestion)">
                            {{ suggestion.title }}
                        </li>
                    </ul>
                </div>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="image in images.data" :key="image.id">
                        <td>
                            <img :src="`http://localhost/authblog_api/public/storage/images/${image.image_path}`" :alt="image.title" width="100" />
                        </td>
                        <td>{{ image.title }}</td>
                        <td>
                            <router-link :to="`/edit/${image.id}`" class="btn btn-primary">Edit</router-link>
                            <button @click="confirmDelete(image.id)" class="btn btn-danger">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- Pagination Links -->
            <div class="pagination">
                <button v-if="images.prev_page_url" @click="fetchImages(images.prev_page_url)" class="btn btn-secondary">
                    Previous
                </button>
                <button v-if="images.next_page_url" @click="fetchImages(images.next_page_url)" class="btn btn-secondary">
                    Next
                </button>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            images: {
                data: [], // Data for the current page
                current_page: 1, // Current page number
                prev_page_url: null, // URL for the previous page
                next_page_url: null // URL for the next page
            },
            searchTitle: '',
            titleSuggestions: [],
            searchQuery: '', // Search query for the title
            perPage: 10 // Items per page
        };
    },
    created() {
        this.fetchImages();
    },
    methods: {
        fetchImages(pageUrl = null) {
            const url = pageUrl || `http://localhost/authblog_api/public/api/images?per_page=${this.perPage}&page=${this.images.current_page}`;
            axios.get(url)
                .then(response => {
                    this.images = response.data;
                })
                .catch(error => {
                    console.error('There was an error fetching the images!', error);
                });
        },
        searchImagesinput() {
            const data = {
                title: this.searchQuery,
                per_page: this.perPage
            };
            axios.post('http://localhost/authblog_api/public/api/images_search', data)
                .then(response => {
                    this.images = response.data;
                })
                .catch(error => {
                    console.error('There was an error searching the images!', error);
                });
        },
        confirmDelete(id) {
            const confirmation = confirm('Are you sure you want to delete this image?');
            if (confirmation) {
                this.deleteImage(id);
            }
        },
        searchImages() {
            axios
                .post(
                    'http://localhost/authblog_api/public/api/images_search', {
                        title: this.searchTitle
                    }, {
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }
                )
                .then((res) => {
                    console.log('API Search Response:', res.data)
                    this.images = res.data
                })
                .catch((error) => {
                    console.error('Error searching students:', error)
                })
        },
        deleteImage(id) {
            axios.delete(`http://localhost/authblog_api/public/api/images/${id}`)
                .then(response => {
                    this.fetchImages();
                    alert(response.data.message);
                })
                .catch(error => {
                    console.error('There was an error deleting the image!', error);
                });
        },
        fetchTitleSuggestions() {
            if (this.searchTitle.length < 1) {
                this.titleSuggestions = [];
                return;
            }

            axios
                .get('http://localhost/authblog_api/public/api/images_search/autocomplete', {
                    params: {
                        term: this.searchTitle
                    },
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    this.titleSuggestions = response.data;
                })
                .catch(error => {
                    console.error('Error fetching title suggestions:', error);
                });
        },
        selectTitleSuggestion(suggestion) {
            this.searchTitle = suggestion.title;
            this.titleSuggestions = [];
            this.searchImages(); // Trigger search with the selected title
        }
    }
};
</script>

<style scoped>
.table {
    width: 100%;
    border-collapse: collapse;
}

.table th,
.table td {
    border: 1px solid #ddd;
    padding: 8px;
}

.table th {
    background-color: #f4f4f4;
}

.table img {
    max-width: 100px;
}

.btn {
    margin-right: 5px;
}

.pagination {
    margin-top: 20px;
    text-align: center;
}

.search-container {
    margin-bottom: 20px;
}

.autocomplete-list {
    list-style: none;
    padding: 0;
    margin: 0;
    border: 1px solid #ddd;
    position: absolute;
    background: #fff;
    z-index: 1000;
    max-height: 200px;
    overflow-y: auto;
}

.autocomplete-list li {
    padding: 8px;
    cursor: pointer;
}

.autocomplete-list li:hover {
    background-color: #f1f1f1;
}
</style>
