import { reactive } from 'vue';

const authState = reactive({
  isAuthenticated: !!localStorage.getItem('token')
});

export default {
  state: authState,
  login(token) {
    localStorage.setItem('token', token);
    authState.isAuthenticated = true;
  },
  logout() {
    localStorage.removeItem('token');
    authState.isAuthenticated = false;
  },
  isLoggedIn() {
    return authState.isAuthenticated;
  }
};
