import { createApp } from "vue";
import App from "./App.vue";
import router from "./router"; // Import the router configuration

createApp(App)
  .use(router) // Use the router instance
  .mount("#app"); // Mount the Vue instance to the DOM
