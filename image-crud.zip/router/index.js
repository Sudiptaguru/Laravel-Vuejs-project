import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import LoginView from '../views/Login.vue';
import ListImages from '../components/ListImages.vue';
import auth from '@/auth'; // Import the authentication service

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/AboutView.vue')
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/datalist',
    name: 'datalist',
    component: ListImages,
    meta: { requiresAuth: true } // Protect the datalist route
  },
  {
    path: '/add',
    name: 'add',
    component: () => import('../components/AddImage.vue'),
    meta: { requiresAuth: true } // Protect the add route
  },
  {
    path: '/edit/:id',
    name: 'edit',
    component: () => import('../components/EditImage.vue'),
    meta: { requiresAuth: true } // Protect the edit route
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

router.beforeEach((to, from, next) => {
  const isLoggedIn = auth.isLoggedIn();
  if (to.matched.some(record => record.meta.requiresAuth) && !isLoggedIn) {
    // Redirect to login page if the route requires authentication and the user is not logged in
    next('/login');
  } else {
    // Proceed to the route
    next();
  }
});

export default router;
