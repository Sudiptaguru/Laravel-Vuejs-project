<template>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h4>Login</h4>
      </div>
      <div class="card-body">
        <ul class="alert alert-warning" v-if="errorList.length > 0">
          <li class="mb-0 ms-3" v-for="(error, index) in errorList" :key="index">
            {{ error }}
          </li>
        </ul>
        <div class="mb-3">
          <label for="email">Email</label>
          <input type="email" v-model="email" class="form-control" />
        </div>
        <div class="mb-3">
          <label for="password">Password</label>
          <input type="password" v-model="password" class="form-control" />
        </div>
        <div class="mb-3">
          <button @click="login" type="button" class="btn btn-primary">Login</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import auth from '@/auth' // Import the authentication service
import { inject } from 'vue'

export default {
  name: 'Login',
  data() {
    return {
      email: '',
      password: '',
      errorList: []
    }
  },
  setup() {
    const authState = inject('authState')
    return {
      authState
    }
  },
  methods: {
    login() {
      const credentials = {
        email: this.email,
        password: this.password
      }

      axios
        .post('http://localhost/authblog_api/public/api/login', credentials, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          alert('Login successful')
          auth.login(res.data.token) // Save the token and update auth state
          this.$router.push('/') // Redirect to home page
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status === 422) {
              this.errorList = Object.values(error.response.data.errors).flat()
            } else if (error.response.status === 401) {
              this.errorList = ['Invalid credentials']
            } else {
              console.log('Error', error.message)
            }
          } else {
            console.log('Error', error.message)
          }
        })
    }
  }
}
</script>
