<template>
  <ul v-if="suggestions.length" class="list-group position-absolute">
    <li
      v-for="(suggestion, index) in suggestions"
      :key="index"
      class="list-group-item list-group-item-action"
      @click="selectSuggestion(suggestion)"
    >
      {{ suggestion.name }} ({{ suggestion.member_id }})
    </li>
  </ul>
</template>

<script>
export default {
  name: 'Autocomplete',
  props: {
    suggestions: {
      type: Array,
      required: true
    }
  },
  methods: {
    selectSuggestion(suggestion) {
      this.$emit('select-suggestion', suggestion)
    }
  }
}
</script>

<style scoped>
.list-group {
  z-index: 1000;
  width: 100%;
}
</style>
