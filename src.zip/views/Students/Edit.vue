<template>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h4>Edit Student</h4>
      </div>
      <div class="card-body">
        <ul class="alert alert-warning" v-if="errorList.length > 0">
          <li class="mb-0 ms-3" v-for="(error, index) in errorList" :key="index">
            {{ error }}
          </li>
        </ul>
        <div class="mb-3">
          <label for="name">Name</label>
          <input type="text" v-model="student.name" class="form-control" id="name" />
        </div>
        <div class="mb-3">
          <label for="memberId">Member Id</label>
          <input type="text" v-model="student.member_id" class="form-control" id="memberId" />
        </div>
        <div class="mb-3">
          <button @click="saveStudent" type="button" class="btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'StudentEdit',
  data() {
    return {
      errorList: [],
      student: {
        id: '',
        name: '',
        member_id: ''
      }
    }
  },
  mounted() {
    this.getStudentData(this.$route.params.id)
  },
  methods: {
    getStudentData(studentId) {
      axios
        .get(`http://localhost/authblog_api/public/api/list/${studentId}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          this.student = res.data
        })
        .catch((error) => {
          console.error('Error fetching student data:', error)
        })
    },
    saveStudent() {
      axios
        .put('http://localhost/authblog_api/public/api/update', this.student, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          alert(res.data.result)
          this.errorList = []
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status === 401) {
              this.errorList = Object.values(error.response.data).flat()
            } else if (error.request) {
              console.log(error.request)
            } else {
              console.log('Error', error.message)
            }
          } else {
            console.log('Error', error.message)
          }
        })
    }
  }
}
</script>
