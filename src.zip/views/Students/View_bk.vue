<template>
  <div class="container">
    <div class="card">
      <div class="card-header">
        <h4>
          Students
          <RouterLink to="students/create" class="btn btn-primary float-end"
            >Add Student</RouterLink
          >
        </h4>
      </div>
      <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
          <input
            type="text"
            v-model="searchName"
            @input="searchStudents"
            placeholder="Search by name"
            class="form-control"
          />
          <input
            type="text"
            v-model="searchMemberId"
            @input="searchStudents"
            placeholder="Search by Member ID"
            class="form-control mt-2"
          />
        </div>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Member Id</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody v-if="students.data.length > 0">
            <tr v-for="(student, index) in students.data" :key="index">
              <td>{{ student.id }}</td>
              <td>{{ student.name }}</td>
              <td>{{ student.member_id }}</td>
              <td>
                <RouterLink :to="'/students/' + student.id + '/edit'" class="btn btn-success"
                  >Edit</RouterLink
                >
                &nbsp;
                <button type="button" @click="deleteStudent(student.id)" class="btn btn-danger">
                  Delete
                </button>
              </td>
            </tr>
          </tbody>
          <tbody v-else>
            <tr>
              <td colspan="4">No students found.</td>
            </tr>
          </tbody>
        </table>
        <!-- Pagination Controls -->
        <nav aria-label="Page navigation">
          <ul class="pagination">
            <li class="page-item" :class="{ disabled: !students.prev_page_url }">
              <a class="page-link" @click.prevent="fetchStudents(students.prev_page_url)"
                >Previous</a
              >
            </li>
            <li class="page-item" :class="{ disabled: !students.next_page_url }">
              <a class="page-link" @click.prevent="fetchStudents(students.next_page_url)">Next</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'students',
  data() {
    return {
      students: {
        data: [],
        next_page_url: null,
        prev_page_url: null
      },
      searchName: '',
      searchMemberId: ''
    }
  },
  mounted() {
    this.getStudents()
  },
  methods: {
    getStudents() {
      axios
        .get('http://localhost/authblog_api/public/api/list', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          this.students = res.data
        })
        .catch((error) => {
          console.error('Error fetching students:', error)
        })
    },
    fetchStudents(url) {
      axios
        .get(url, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          this.students = res.data
        })
        .catch((error) => {
          console.error('Error fetching students:', error)
        })
    },
    searchStudents() {
      axios
        .post(
          'http://localhost/authblog_api/public/api/search',
          {
            name: this.searchName,
            member_id: this.searchMemberId
          },
          {
            headers: {
              'Content-Type': 'application/json',
              Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
            }
          }
        )
        .then((res) => {
          console.log('API Search Response:', res.data)
          this.students = res.data
        })
        .catch((error) => {
          console.error('Error searching students:', error)
        })
    },
    deleteStudent(studentId) {
      if (confirm('Are you sure you want to delete this student?')) {
        axios
          .delete(`http://localhost/authblog_api/public/api/delete/${studentId}`, {
            headers: {
              'Content-Type': 'application/json',
              Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
            }
          })
          .then((res) => {
            alert(res.data.result)
            this.getStudents() // Refresh the list after deletion
          })
          .catch((error) => {
            if (error.response) {
              if (error.response.status === 500) {
                this.errorList = Object.values(error.response.data).flat()
              } else if (error.request) {
                console.log(error.request)
              } else {
                console.log('Error', error.message)
              }
            } else {
              console.log('Error', error.message)
            }
          })
      }
    }
  }
}
</script>
