<template>
  <div class="container mt-5">
    <div class="card">
      <div class="card-header">
        <h4>Add Students</h4>
      </div>
      <div class="card-body">
        <!-- Global errors -->
        <ul class="alert alert-warning" v-if="showErrors && globalErrors.length > 0">
          <li class="mb-0 ms-3" v-for="(error, index) in globalErrors" :key="index">
            {{ error }}
          </li>
        </ul>
        <div class="mb-3">
          <label for="name">Name</label>
          <input type="text" v-model="model.student.name" class="form-control" id="name" />
          <!-- Field-specific errors -->
          <div v-if="showErrors && errorList.name.length > 0" class="alert alert-warning mt-1">
            <div v-for="(error, index) in errorList.name" :key="index">
              {{ error }}
            </div>
          </div>
        </div>
        <div class="mb-3">
          <label for="member_id">Member Id</label>
          <input
            type="text"
            v-model="model.student.member_id"
            class="form-control"
            id="member_id"
          />
          <!-- Field-specific errors -->
          <div v-if="showErrors && errorList.member_id.length > 0" class="alert alert-warning mt-1">
            <div v-for="(error, index) in errorList.member_id" :key="index">
              {{ error }}
            </div>
          </div>
        </div>
        <div class="mb-3">
          <button @click="saveStudent" type="button" class="btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'studentCreate',
  data() {
    return {
      showErrors: false, // Control visibility of validation errors
      globalErrors: [], // To hold global errors, if any
      errorList: {
        name: [],
        member_id: []
      },
      model: {
        student: {
          name: '',
          member_id: ''
        }
      }
    }
  },
  methods: {
    saveStudent() {
      this.showErrors = true // Show errors on submit attempt
      axios
        .post('http://localhost/authblog_api/public/api/validate', this.model.student, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer 13|mB8Ih7VaEpwapAoLaNusDYxRiBX4ERfIEFtm8hm0'
          }
        })
        .then((res) => {
          console.log('API Response:', res.data)
          alert(res.data.result)
          this.model.student = {
            name: '',
            member_id: ''
          }
          this.errorList = { name: [], member_id: [] } // Clear errors
          this.globalErrors = [] // Clear global errors
        })
        .catch((error) => {
          if (error.response) {
            if (error.response.status == 401) {
              // Assuming errors are grouped by field names
              this.errorList = {
                name: error.response.data.name || [],
                member_id: error.response.data.member_id || []
              }
              this.globalErrors = [] // Clear global errors
            } else {
              // Handle other types of errors
              this.globalErrors = [error.response.data.message || 'An error occurred.']
              this.errorList = { name: [], member_id: [] }
            }
          } else if (error.request) {
            console.log(error.request)
          } else {
            console.log('Error', error.message)
          }
        })
    }
  }
}
</script>
