<template>
  <header>
    <div class="wrapper">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <RouterLink class="navbar-brand" to="#">Dashboard</RouterLink>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0">
              <li class="nav-item">
                <RouterLink class="nav-link active" aria-current="page" to="/">Home</RouterLink>
              </li>
              <li class="nav-item">
                <RouterLink class="nav-link" to="/about">About Us</RouterLink>
              </li>
              <li class="nav-item">
                <RouterLink class="nav-link" to="/students">Students</RouterLink>
              </li>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item" v-if="!isLoggedIn">
                <RouterLink class="nav-link" to="/login">Login</RouterLink>
              </li>
              <li class="nav-item" v-if="isLoggedIn">
                <RouterLink class="nav-link" to="/" @click.prevent="logout">Logout</RouterLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>

  <RouterView />
</template>

<script>
import auth from '@/auth' // Import the authentication service

export default {
  name: 'App',
  computed: {
    isLoggedIn() {
      return auth.isLoggedIn()
    }
  },
  methods: {
    logout() {
      auth.logout()
      this.$router.push('/login') // Redirect to login page
    }
  },
  created() {
    if (!this.isLoggedIn) {
      this.$router.push('/login') // Redirect to login page if not logged in
    }
  }
}
</script>

<style scoped>
/* Add your styles here */
</style>
