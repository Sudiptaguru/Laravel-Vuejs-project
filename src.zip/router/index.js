import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import StudentView from '../views/Students/View.vue'
import StudentCreate from '../views/Students/Create.vue'
import StudentEdit from '../views/Students/Edit.vue'
import LoginView from '../views/Login.vue'
import auth from '@/auth' // Import the authentication service

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/AboutView.vue') // Lazy-loaded route
  },
  {
    path: '/students',
    name: 'students',
    component: StudentView,
    meta: { requiresAuth: true } // Requires authentication
  },
  {
    path: '/students/create',
    name: 'studentCreate',
    component: StudentCreate,
    meta: { requiresAuth: true } // Requires authentication
  },
  {
    path: '/students/:id/edit',
    name: 'studentEdit',
    component: StudentEdit,
    meta: { requiresAuth: true } // Requires authentication
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const isLoggedIn = auth.isLoggedIn()
  if (to.matched.some((record) => record.meta.requiresAuth) && !isLoggedIn) {
    // Redirect to login page if the route requires authentication and user is not logged in
    next('/login')
  } else {
    // Proceed to the route
    next()
  }
})

export default router
