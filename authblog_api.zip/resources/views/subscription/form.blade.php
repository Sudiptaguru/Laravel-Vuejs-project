<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribe</title>
</head>
<body>
    <form action="{{ route('subscribe') }}" method="POST" id="payment-form">
        @csrf
        <div id="card-element">
            <!-- A Stripe Element will be inserted here. -->
        </div>
        <button type="submit" id="card-button" data-secret="{{ $intent->client_secret }}">
            Subscribe
        </button>
    </form>

    <script src="https://js.stripe.com/v3/"></script>
    <script>
        // Initialize Stripe.js with your publishable key
        var stripe = Stripe('{{ env('STRIPE_KEY') }}');
        var elements = stripe.elements();

        // Create an instance of the card Element
        var cardElement = elements.create('card');
        cardElement.mount('#card-element');

        // Handle form submission
        var form = document.getElementById('payment-form');
        var clientSecret = document.getElementById('card-button').getAttribute('data-secret');

        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            // Confirm the card setup with the client secret and payment method
            const { setupIntent, error } = await stripe.confirmCardSetup(
                clientSecret, {
                    payment_method: {
                        card: cardElement,
                        billing_details: {
                            name: 'Customer Name' // Update with the user's name
                        },
                    },
                }
            );

            if (error) {
                // Show error to your customer (e.g., insufficient funds)
                console.error(error.message);
            } else {
                // Send the payment method ID to your server
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'payment_method');
                hiddenInput.setAttribute('value', setupIntent.payment_method);
                form.appendChild(hiddenInput);

                // Submit the form
                form.submit();
            }
        });
    </script>
</body>
</html>
