<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Device;
use App\Models\User;
use Validator;
class DeviceController extends Controller
{
    public function list(Request $request, $id = null)
    {
        if ($id) {
            return Device::find($id);
        } else {
            // Retrieve paginated devices
            $perPage = $request->input('per_page', 10); // Default to 15 items per page
            $devices = Device::paginate($perPage);
            return $devices;
        }
    }

    function add(Request $req)
    {
    	$device = new Device;
    	$device->name=$req->name;
    	$device->member_id=$req->member_id;
    	$result=$device->save();
    	if ($result) {
            return response()->json(['result' => 'Data has been saved']);
        } else {
            return response()->json(['result' => 'Operation failed'], 500);
        }
    }

    function update(Request $req)
    {
        $device = Device::find($req->id);
        $device->name=$req->name;
        $device->member_id=$req->member_id;
        $result=$device->save();
        if ($result) {
            return response()->json(['result' => 'Data has been updated']);
        } else {
            return response()->json(['result' => 'Operation failed'], 500);
        }
    }

    function delete($id)
    {
        $device = Device::find($id);
        $result=$device->delete();
        if ($result) {
            return response()->json(['result' => 'Data has been deleteed']);
        } else {
            return response()->json(['result' => 'Operation failed'], 500);
        }
    }

    // function search($name)
    // {
    //     // return Device::where("name",$name)->get();
    //     return Device::where("name", "like", "%".$name."%")->get();
    // }
    // public function search(Request $request)
    // {
    //     $name = $request->input('name');
    //     $memberId = $request->input('member_id');
    //     $query = Device::query();
    //     if (!empty($name)) {
    //         $query->where("name", "like", "%".$name."%");
    //     }
    //     if (!empty($memberId)) {
    //         $query->where("member_id", $memberId);
    //     }
    //     $perPage = $request->input('per_page', 10);
    //     $devices = $query->paginate($perPage);
    //     $devices->appends([
    //         'name' => $name,
    //         'member_id' => $memberId,
    //     ]);

    //     return response()->json($devices);
    // }

    public function search(Request $request)
    {
        // Retrieve search parameters from request
        $name = $request->input('name');
        $memberId = $request->input('member_id');

        // Build the query
        $query = Device::query();

        // Search by name
        if (!empty($name)) {
            $query->where('name', 'like', "%{$name}%");
        }

        // Search by member_id if provided
        if (!empty($memberId)) {
            $query->where('member_id', $memberId);
        }

        // Set the number of items per page
        $perPage = $request->input('per_page', 10); // Default to 10 items per page

        // Paginate the results
        $devices = $query->paginate($perPage);

        // Append the search parameters to pagination links
        $devices->appends([
            'name' => $name,
            'member_id' => $memberId,
            'per_page' => $perPage
        ]);

        return response()->json($devices);
    }
    public function autocomplete(Request $request)
    {
        $term = $request->input('term');

        $query = Device::query();

        if (!empty($term)) {
            $query->where(function($query) use ($term) {
                $query->where('name', 'like', "%{$term}%")
                      ->orWhere('member_id', 'like', "%{$term}%");
            });
        }

        $devices = $query->limit(10)->get(['name', 'member_id']);

        return response()->json($devices);
    }

    function testData(Request $req)
    {
        $rules=array(
            "member_id"=>"required",
            "name"=>"required | max:4"
        );
        $validator=validator::make($req->all(),$rules);
        if($validator->fails())
        {
            // return $validator->errors();
            return response()->json($validator->errors(),401);
        }
        else
        {
            // return ["a"=>"x"];
            $device = new Device;
            $device->name=$req->name;
            $device->member_id=$req->member_id;
            $result=$device->save();
            if ($result) {
                return response()->json(['result' => 'Data hasbeen saved']);
            } else {
                return response()->json(['result' => 'Operation failed'], 500);
            }
        }
    }
    function validateData(Request $req)
    {
        $rules=array(
            "name"=>"required|max:20|in:demo",
            "email"=>"required|email|in:demo@gmail.com",
            "password"=>"required|in:12345"
        );
        $validator=validator::make($req->all(),$rules);
        if($validator->fails())
        {
            // return $validator->errors();
            return response()->json($validator->errors(),401);
        }
        else
        {
            // return response()->json(['result' => 'Data hasbeen validated']);
            // return ["a"=>"x"];
            $user = new User;
            $user->name=$req->name;
            $user->email=$req->email;
            $user->password=$req->password;
            $result=$user->save();
            if ($result) {
                return response()->json(['result' => 'Data hasbeen saved']);
            } else {
                return response()->json(['result' => 'Operation failed'], 500);
            }
        }
    }
}
