<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// app/Http/Controllers/ImageController.php

namespace App\Http\Controllers;

use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{
    public function index(Request $request)
    {
        $perPage = $request->get('per_page', 10); // Number of images per page, default is 10
        return Image::paginate($perPage);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $imageName = time().'.'.$request->image->extension();
        $request->image->storeAs('public/images', $imageName);

        $image = new Image();
        $image->title = $request->title;
        $image->image_path = $imageName;
        $image->save();

        return response()->json(['message' => 'Data added successfully!', 'image' => $image]);
    }

    public function show($id)
    {
        return Image::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $image = Image::findOrFail($id);

        $request->validate([
            'title' => 'required|string|max:255',
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($request->hasFile('image')) {
            // Delete old image
            Storage::delete('public/images/'.$image->image_path);

            $imageName = time().'.'.$request->image->extension();
            $request->image->storeAs('public/images', $imageName);
            $image->image_path = $imageName;
        }

        $image->title = $request->title;
        $image->save();

        return response()->json(['message' => 'Data updated successfully!', 'image' => $image]);
    }

    public function destroy($id)
    {
        $image = Image::findOrFail($id);
        Storage::delete('public/images/'.$image->image_path);
        $image->delete();

        return response()->json(['message' => 'Data deleted successfully!']);
    }

    public function search(Request $request)
	{
	    $title = $request->input('title');

	    $query = Image::query();

	    if (!empty($title)) {
            $query->where('title', 'like', "%{$title}%");
        }
        $perPage = $request->input('per_page', 10);

	    $images = $query->paginate($perPage);
	    $images->appends([
            'title' => $title,
            'per_page' => $perPage
        ]);

	    return response()->json($images);
	}
	public function autocomplete(Request $request)
	{
	    $term = $request->input('term');

	    $query = Image::query();

	    if (!empty($term)) {
	        $query->where(function($query) use ($term) {
	            $query->where('title', 'like', "%{$term}%");
	        });
	    }

	    $images = $query->limit(10)->get(['title']);

	    return response()->json($images);
	}
}
