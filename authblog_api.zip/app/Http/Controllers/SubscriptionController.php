<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Laravel\Cashier\Exceptions\PaymentActionRequired;
use Laravel\Cashier\Exceptions\IncompletePayment;
use Stripe\Stripe;
use Stripe\SetupIntent;
use App\Models\User;
use App\Services\StripeService;

class SubscriptionController extends Controller
{
    protected $stripeService;

    public function __construct(StripeService $stripeService)
    {
        $this->stripeService = $stripeService;
    }

    public function showSubscriptionForm()
    {
        $intent = $this->stripeService->createSetupIntent();

        return view('subscription.form', ['intent' => $intent]);
    }

    public function subscribe(Request $request)
    {
        $paymentMethod = $request->input('payment_method');
        $email = 'sudiptaguru74@gmail.com'; // Use appropriate user email or other means to get email
        $name = 'Sudipta Guru'; // Use appropriate customer name
        $priceId = '1'; // Replace with your Stripe price ID

        $customer = $this->stripeService->createCustomer($email, $name);
        $subscription = $this->stripeService->createSubscription($customer->id, $priceId, $paymentMethod);

        return redirect('/home')->with('success', 'Subscription successful!');
    }
}