<?php

namespace App\Services;

use Stripe\StripeClient;

class StripeService
{
    protected $stripe;

    public function __construct()
    {
        $this->stripe = new StripeClient(env('STRIPE_SECRET'));
    }

    public function createCustomer($email, $name)
    {
        return $this->stripe->customers->create([
            'email' => $email,
            'name' => $name,
        ]);
    }

    public function createSubscription($customerId, $priceId, $paymentMethodId)
    {
        return $this->stripe->subscriptions->create([
            'customer' => $customerId,
            'items' => [['price' => $priceId]],
            'default_payment_method' => $paymentMethodId,
        ]);
    }

    public function createSetupIntent()
    {
        return $this->stripe->setupIntents->create();
    }
}
