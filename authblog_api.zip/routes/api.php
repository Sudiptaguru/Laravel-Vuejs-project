<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DeviceController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ImageController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['middleware' => 'auth:sanctum'], function(){
 	Route::get("list/{id?}",[DeviceController::class,'list']);
	Route::post("add",[DeviceController::class,'add']);
	Route::put("update",[DeviceController::class,'update']);
	Route::delete("delete/{id}",[DeviceController::class,'delete']);
	// Route::get("search/{name}",[DeviceController::class,'search']);
	Route::post('search', [DeviceController::class, 'search']);
	Route::get('devices/autocomplete', [DeviceController::class, 'autocomplete']);
	Route::post("validate",[DeviceController::class,'testData']);
    Route::post("validatedata",[DeviceController::class,'validateData']);
	Route::apiResource("member",MemberController::class);
	Route::post("login",[UserController::class,'index']);
	Route::post('logout', [UserController::class, 'logout']);

});
// Route::post("login",[UserController::class,'index']);

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::get("list/{id?}",[DeviceController::class,'list']);
// Route::post("add",[DeviceController::class,'add']);
// Route::put("update",[DeviceController::class,'update']);
// Route::delete("delete/{id}",[DeviceController::class,'delete']);
// Route::get("search/{name}",[DeviceController::class,'search']);
// Route::post("validate",[DeviceController::class,'testData']);
// Route::apiResource("member",MemberController::class);
// Route::post("login",[UserController::class,'index']);

Route::get('/images', [ImageController::class, 'index']);
Route::post('/images', [ImageController::class, 'store']);
Route::get('/images/{id}', [ImageController::class, 'show']);
Route::post('/images/{id}', [ImageController::class, 'update']);
Route::delete('/images/{id}', [ImageController::class, 'destroy']);
Route::post('images_search', [ImageController::class, 'search']);
Route::get('images_search/autocomplete', [ImageController::class, 'autocomplete']);